<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ClienteController;
use App\Http\Controllers\ProductoController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});


Route:: view(uri:'login', view:'login');

/* clientes */

Route::get('/clientes', [ClienteController::class, 'index']);
Route::post('/clientes/', [ClienteController::class, 'store']);
Route::get('/clientes/crear', [ClienteController::class, 'create']);

Route::get('/clientes/{id}/editar', [ClienteController::class, 'edit']);
Route::post('/clientes/{id}/editar', [ClienteController::class, 'update']);
Route::get('/clientes/{id}/eliminar', [ClienteController::class, 'destroy']);

/* productos */

Route::get('/productos', [ProductoController::class, 'index']);
Route::post('/productos', [ProductoController::class, 'store']);

Route::get('/productos/crear', [ProductoController::class, 'create']);


/* marcas */

Route::get('/marcas', [\App\Http\Controllers\MarcaController::class, 'index']);
Route::get('/marcas/crear', [\App\Http\Controllers\MarcaController::class, 'create']);

/*** Acceso ***/

//Route::view('/login', 'acceso.login');

//Route::post('/login', [UserController::class, 'login']);





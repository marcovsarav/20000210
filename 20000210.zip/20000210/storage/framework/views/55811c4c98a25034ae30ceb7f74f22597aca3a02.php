<form

     <?php if($cliente->idCliente != null): ?>
      action="/clientes/<?php echo e($cliente->idCliente); ?>/editar" method="post"
     <?php else: ?>
         action= "/clientes" method= "post"
         <?php endif; ?>
>
    <?php echo e(csrf_field()); ?>


    <input type="hidden" id="idCliente" name="idCliente" value="<?php echo e($cliente->idCliente); ?>">

    <div class="row">
        <div class="row-cols-m-6">
            <label for="lastName" class="form-label">NIT................</label>
            <input type="text" class="form-control" id="nit" name="nit" placeholder="626212-K" value="<?php echo e($cliente->nit); ?>" required="">
        </div>

        <div class="row-cols-m-6">
            <label for="lastName" class="form-label">NOMBRE.....</label>
            <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Nombre completo" value="<?php echo e($cliente->nombre); ?>" required="">
        </div>

        <div class="row-cols-m-6">
            <label for="username" class="form-label">DIRECCION</label>

                <input type="text" class="form-control" id="direccion" name="direccion" placeholder="Dirección exacta" value="<?php echo e($cliente->direccion); ?>" required="">
            </div>
        </div>

        <hr class="my-4">

        <input type="submit" class="w-150 btn btn-sm btn-outline-info" value="Guardar">
    </div>


</form>
<?php /**PATH D:\proyectos\20000210\resources\views/partial/clientes/forms.blade.php ENDPATH**/ ?>
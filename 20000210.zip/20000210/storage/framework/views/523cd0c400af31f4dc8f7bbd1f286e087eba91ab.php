<?php $__env->startSection('content'); ?>
    <header>
        <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
            <div class="container-fluid">
                <a class="nav-link" href="#">SUPERMERCADO: SMARTMARKET
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" >

                            <li class="nav-item">
                                <a class="nav-link" href="/clientes">CLIENTES</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="/productos">PRODUCTOS</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="/marcas">MARCAS</a>
                            </li>
                        </ul>
                        
                        
                        
                        
                        <a class="btn btn-outline-info" href="/login">INICIO DE SESION (Empleados) </a>
                    </div>
            </div>
        </nav>
    </header>

    <main>

        <div id="myCarousel" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-indicators">
                <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="1" aria-label="Slide 2"></button>
                <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="2" aria-label="Slide 3"></button>
            </div>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img alt src="<?php echo e(URL::asset('assets/img/descarga6.jpg')); ?>">
                    <svg class="small-placeholder-img" width="100%" height="200%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false"><rect width="45%" height="45%" fill="#1077"/></svg>

                    <div class="container">
                        <div class="carousel-caption text-start">
                            <h1 style="color: darkblue;">¡Ya disponible !</h1>
                            <p style="color:darkblue;"> Prueba nuestro servicio de venta online.</p>
                            <p><a class="btn btn-lg btn-primary" href="#"> ¡Click aqui para mas informacion!</a></p>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">  <img src="<?php echo e(URL::asset('assets/img/descarga10.jpg')); ?>">
                    <svg class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false"><rect width="100%" height="100%" fill="#777"/></svg>

                    <div class="container">
                        <div class="carousel-caption">
                            <h1>.</h1>
                            <p style="color:darkblue"> Los mejores productos importados y los productos premium nacionales.</p>
                            <p><a class="btn btn-lg btn-primary" href="#">Ingresa a nuestro catalogo</a></p>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">  <img src="<?php echo e(URL::asset('assets/img/descarga3.jpg')); ?>">
                    <svg class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false"><rect width="100%" height="100%" fill="#777"/></svg>

                    <div class="container">
                        <div class="carousel-caption text-end">

                            <p  style="color: darkslateblue;  "> Aprovecha la comodidad que te ofrecen  nuestros carritos inteligentes.</p>
                            <p><a class="btn btn-lg btn-primary" href="#">!Aquí puedes ver las ventajas de los carritos inteligentes Amazon Dash Cart</a></p>
                        </div>
                    </div>
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#myCarousel" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#myCarousel" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>


        <!-- Marketing messaging and featurettes
        ================================================== -->
        <!-- Wrap the rest of the page in another container to center all the content. -->















































































        <!-- FOOTER -->
        <footer class="container">
            <p class="float-end"><a href="#">Back to top</a></p>
            <p>&copy; 2017–2021 Company, Inc. &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
        </footer>



    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyectos\20000210\resources\views/index.blade.php ENDPATH**/ ?>
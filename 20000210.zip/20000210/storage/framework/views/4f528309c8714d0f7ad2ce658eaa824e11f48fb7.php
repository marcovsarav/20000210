<?php $__env->startSection('content'); ?>
    <header>
        <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
            <div class="container-fluid" >
                <a class="nav-link" href="/">SUPERMERCADO: SMARTMARKET
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarCollapse">

                        <li class="nav-item">
                            <a class="nav-link"  href="/clientes">CLIENTES</a>
                        </li>
                        <div class="collapse navbar-collapse" id="navbarCollapse">

                            <li class="nav-item">
                                <a class="nav-link" href="/productos">PRODUCTOS</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="/marcas">MARCAS</a>

                            </li>
                            </ul>
                                            <form class="d-flex">

                                                <button class="btn btn-outline-success" type="submit">Search</button>
                                            </form>
                            <li class="nav-item">
                                <a class="btn btn-outline-info" href="/login">INICIO DE SESION (Empleados) </a>
                            </li>
                        </div>
                    </div>
        </nav>
    </header>





    <div class="container marketing">

        <!-- Three columns of text below the carousel -->
        <div class="row">
            <div class="col-lg-4">

                <img src='<?php echo e(URL::asset('assets/img/descarga2.jpg')); ?>'class='imgcircle' alt="" width="65%" height="50%"/>
                <h2> Marcas</h2>
                <h2>Listado de Marcas</h2>
                <a href="/marcas/crear" class="btn btn-sm btn-outline-success">Nuevo</a>
                <div class="table-responsive">
                    <table class="table table-striped table-sm table-hover">
                        <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">IdMarca</th>
                            <th scope="col">Precio</th>
                            <th scope="col">Nombre</th>
                            <th scope="col">IdProducto</th>
                            <th scope="col">Operaciones</th>
                        </tr>
                        </thead>
                        <?php
                            $contador = 0;
                        ?>
                        <tbody>
                        <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$contador); ?></td>
                                <td><?php echo e($marca->idMarca); ?></td>
                                <td><?php echo e($marca->nombre); ?></td>
                                <td><?php echo e($marca->precio); ?></td>
                                <td>
                                    <div class="mt-1">
                                        <a href="/marcas/<?php echo e($marca->idMarca); ?>/editar" class="btn btn-sm btn-outline-warning">Editar</a>

                                        <a href="/marcas/<?php echo e($marca->idMarca); ?>/eliminar" class="btn btn-sm btn-outline-danger">Eliminar</a>


                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <p><a class="btn btn-secondary" href=""></a></p>



            </div><!-- /.container -->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyectos\20000210\resources\views/marcas/index.blade.php ENDPATH**/ ?>
@extends('layout.master')
@section('content')
    <header>
        <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
            <div class="container-fluid" >
                <a class="nav-link" href="/">SUPERMERCADO: SMARTMARKET
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarCollapse">

                            <li class="nav-item">
                                <a class="nav-link"  href="/clientes">CLIENTES</a>
                            </li>
                            <div class="collapse navbar-collapse" id="navbarCollapse">

                            <li class="nav-item">
                                <a class="nav-link" href="/productos">PRODUCTOS</a>
                            </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="/marcas">MARCAS</a>
                                </li>
                        </ul>
                        {{--                <form class="d-flex">--}}
                        {{--                    <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">--}}
                        {{--                    <button class="btn btn-outline-success" type="submit">Search</button>--}}
                        {{--                </form>--}}
                                <li class="nav-item">
                        <a class="btn btn-outline-info" href="/login">INICIO DE SESION (Empleados) </a>
                                </li>
                    </div>
            </div>
        </nav>
    </header>

    <div class="container marketing">

        <!-- Three columns of text below the carousel -->
        <div class="row">
            <div class="col-lg-4">
                {{--                <svg class="bd-placeholder-img rounded-circle" width="140" height="140" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 140x140" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#777"/><text x="50%" y="50%" fill="#777" dy=".3em">140x140</text></svg>--}}
                <img src='{{URL::asset('assets/img/registro_cliente.jpg')}}'class='imgcircle' alt="" width="65%" height="50%"/>
                <h2> CLIENTES</h2>
                <h2>Listado de clientes</h2>
                <a href="/clientes/crear" class="btn btn-sm btn-outline-success"> Nuevo</a>

                <div class="table-responsive">

                    <table class="table table-striped table-sm table-hover">
                        <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">ID</th>
                            <th scope="col">NIT</th>
                            <th scope="col">Nombre</th>
                            <th scope="col">Dirección</th>
                            <th scope="col">Operaciones</th>
                        </tr>
                        </thead>
                        @php
                            $contador = 0;
                        @endphp
                        <tbody>
                        @foreach($clientes as $cliente)
                            <tr>
                                <td>{{++$contador}}</td>
                                <td>{{$cliente->idCliente}}</td>
                                <td>{{$cliente->nit}}</td>
                                <td>{{$cliente->nombre}}</td>
                                <td>{{$cliente->direccion}}</td>
                                <td>
                                    <div class="mt-1">
                                       <a href="/clientes/{{$cliente->idCliente}}/editar" class="btn btn-sm btn-outline-warning">Editar </a>
                                       <a href="/clientes/{{$cliente->idCliente}}/eliminar" class="btn btn-sm btn-outline-danger">Eliminar </a>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>

                <p><a class="btn btn-secondary" href=""></a></p>



{{--            </div><!-- /.col-lg-4 -->--}}
{{--            <div class="col-lg-4">--}}
{{--                --}}{{--                <svg class="bd-placeholder-img rounded-circle" width="140" height="140" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 140x140" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#777"/><text x="50%" y="50%" fill="#777" dy=".3em">140x140</text></svg>--}}
{{--                <img src='{{URL::asset('assets/img/editar.jpg')}}'class='imgcircle' alt="" width="50%" height="50%"/>--}}

{{--                <h2>Editar</h2>--}}
{{--                <p>Edicion.</p>--}}
{{--                <p><a class="btn btn-secondary" href="#">Ingreso &raquo;</a></p>--}}
{{--            </div><!-- /.col-lg-4 -->--}}
{{--            <div class="col-lg-4">--}}
{{--                --}}{{--                <svg class="bd-placeholder-img rounded-circle" width="140" height="140" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 140x140" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#777"/><text x="50%" y="50%" fill="#777" dy=".3em">140x140</text></svg>--}}

{{--                <img src='{{URL::asset('assets/img/eliminar.jpg')}}'class='imgcircle' alt="" width="50%" height="50%"/>--}}
{{--                <h2>Eliminar</h2>--}}
{{--                <p> Dar de baja </p>--}}
{{--                <p><a class="btn btn-secondary" href="#">Ingreso &raquo;</a></p>--}}
{{--            </div><!-- /.col-lg-4 -->--}}
{{--        </div><!-- /.row -->--}}


        <!-- START THE FEATURETTES -->

        {{--        <hr class="featurette-divider">--}}

        {{--        <div class="row featurette">--}}
        {{--            <div class="col-md-7">--}}
        {{--                <h2 class="featurette-heading">First featurette heading. <span class="text-muted">It’ll blow your mind.</span></h2>--}}
        {{--                <p class="lead">Some great placeholder content for the first featurette here. Imagine some exciting prose here.</p>--}}
        {{--            </div>--}}
        {{--            <div class="col-md-5">--}}
        {{--                <svg class="bd-placeholder-img bd-placeholder-img-lg featurette-image img-fluid mx-auto" width="500" height="500" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 500x500" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#eee"/><text x="50%" y="50%" fill="#aaa" dy=".3em">500x500</text></svg>--}}

        {{--            </div>--}}
        {{--        </div>--}}

        {{--        <hr class="featurette-divider">--}}

        {{--        <div class="row featurette">--}}
        {{--            <div class="col-md-7 order-md-2">--}}
        {{--                <h2 class="featurette-heading">/ <span class="text-muted">See for yourself.</span></h2>--}}
        {{--                <p class="lead">Another featurette? Of course. More placeholder content here to give you an idea of how this layout would work with some actual real-world content in place.</p>--}}
        {{--            </div>--}}
        {{--            <div class="col-md-5 order-md-1">--}}
        {{--                <svg class="bd-placeholder-img bd-placeholder-img-lg featurette-image img-fluid mx-auto" width="500" height="500" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 500x500" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#eee"/><text x="50%" y="50%" fill="#aaa" dy=".3em">500x500</text></svg>--}}

        {{--            </div>--}}
        {{--        </div>--}}

        {{--        <hr class="featurette-divider">--}}

        {{--        <div class="row featurette">--}}
        {{--            <div class="col-md-7">--}}
        {{--                <h2 class="featurette-heading">And lastly, this one. <span class="text-muted">Checkmate.</span></h2>--}}
        {{--                <p class="lead">And yes, this is the last block of representative placeholder content. Again, not really intended to be actually read, simply here to give you a better view of what this would look like with some actual content. Your content.</p>--}}
        {{--            </div>--}}
        {{--            <div class="col-md-5">--}}
        {{--                <svg class="bd-placeholder-img bd-placeholder-img-lg featurette-image img-fluid mx-auto" width="500" height="500" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 500x500" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#eee"/><text x="50%" y="50%" fill="#aaa" dy=".3em">500x500</text></svg>--}}

        {{--            </div>--}}
        {{--        </div>--}}

        {{--        <hr class="featurette-divider">--}}

        {{--        <!-- /END THE FEATURETTES -->--}}

    </div><!-- /.container -->


@endsection

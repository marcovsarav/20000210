<form

     action= "/productos" method= "post"
>
    {{csrf_field()}}


    <div class="row">
        <div class="row-cols-lg-auto">
            <label for="lastName" class="form-label">MARCA</label>
            <select class="form-control"id="idMarca" name="idMarca" required="">
                @foreach($marcas as $marca )
                    <option value="{{$marca->idMarca}}">@if($producto->idMarca == $marca->idMarca)select @endif >{{$marca->nombre}}</option>
                @endforeach

            </select>

        </div>

        <div class="row-cols-sm-8">
            <label for="lastName" class="form-label">NOMBRE</label>
            <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Nombre producto" value="{{$producto->nombre}}" required="">
        </div>

        <div class="row-cols-sm-8">
            <label for="username" class="form-label">PRECIO</label>

            <div class="input-group cols-sm-8">
                <div class="input-group-prepend">
                    <span class="input-group-text">GTQ</span>
                </div>
                <input type="number" class="form-control" id="precio" name="precio" min="0.00" step="0.01" ""aria-label="Amount (to the nearest dollar)">
                <div class="input-group-append">
                    <span class="input-group-text">.00</span>
                </div>
              </div>

    <hr class="my-4">

    <input type="submit" class="w-150 btn btn-sm btn-outline-info" value="Guardar">
    </div>


</form>


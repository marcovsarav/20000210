<form

     @if($cliente->idCliente != null)
      action="/clientes/{{$cliente->idCliente}}/editar" method="post"
     @else
         action= "/clientes" method= "post"
         @endif
>
    {{csrf_field()}}

    <input type="hidden" id="idCliente" name="idCliente" value="{{$cliente->idCliente}}">

    <div class="row">
        <div class="row-cols-m-6">
            <label for="lastName" class="form-label">NIT................</label>
            <input type="text" class="form-control" id="nit" name="nit" placeholder="626212-K" value="{{$cliente->nit}}" required="">
        </div>

        <div class="row-cols-m-6">
            <label for="lastName" class="form-label">NOMBRE.....</label>
            <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Nombre completo" value="{{$cliente->nombre}}" required="">
        </div>

        <div class="row-cols-m-6">
            <label for="username" class="form-label">DIRECCION</label>

                <input type="text" class="form-control" id="direccion" name="direccion" placeholder="Dirección exacta" value="{{$cliente->direccion}}" required="">
            </div>
        </div>

        <hr class="my-4">

        <input type="submit" class="w-150 btn btn-sm btn-outline-info" value="Guardar">
    </div>


</form>

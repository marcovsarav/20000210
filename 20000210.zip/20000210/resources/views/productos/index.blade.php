@extends('layout.master')
@section('content')
    <header>
        <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
            <div class="container-fluid" >
                <a class="nav-link" href="/">SUPERMERCADO: SMARTMARKET
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarCollapse">

                        <li class="nav-item">
                            <a class="nav-link"  href="/clientes">CLIENTES</a>
                        </li>
                        <div class="collapse navbar-collapse" id="navbarCollapse">

                            <li class="nav-item">
                                <a class="nav-link" href="/productos">PRODUCTOS</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="/marcas">MARCAS</a>
                            </li>
                            </ul>
                            {{--                <form class="d-flex">--}}
                            {{--                    <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">--}}
                            {{--                    <button class="btn btn-outline-success" type="submit">Search</button>--}}
                            {{--                </form>--}}
                            <li class="nav-item">
                                <a class="btn btn-outline-info" href="/login">INICIO DE SESION (Empleados) </a>
                            </li>
                        </div>
                    </div>
        </nav>
    </header>





    <div class="container marketing">

        <!-- Three columns of text below the carousel -->
        <div class="row">
            <div class="col-lg-4">
                {{--                <svg class="bd-placeholder-img rounded-circle" width="140" height="140" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 140x140" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#777"/><text x="50%" y="50%" fill="#777" dy=".3em">140x140</text></svg>--}}
                <img src='{{URL::asset('assets/img/producto1.jpg')}}'class='imgcircle' alt="" width="65%" height="50%"/>
                <h2> Productos</h2>
                <h2>Listado de Productos</h2>
                <a href="/productos/crear" class="btn btn-sm btn-outline-success">Nuevo</a>
                <div class="table-responsive">
                    <table class="table table-striped table-sm table-hover">
                        <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">IdMarca</th>
                            <th scope="col">Precio</th>
                            <th scope="col">Nombre</th>
                            <th scope="col">IdProducto</th>
                            <th scope="col">Operaciones</th>
                        </tr>
                        </thead>
                        @php
                            $contador = 0;
                        @endphp
                        <tbody>
                        @foreach($productos as $producto)
                            <tr>
                                <td>{{++$contador}}</td>
                                <td>{{$producto->idProducto}}</td>
                                <td>{{$producto->precio}}</td>
                                <td>{{$producto->nombre}}</td>
                                <td>{{$producto->idMarca}}</td>
                                <td>
                                    <div class="mt-1">
                                        <a href="/productos/{{$producto->idProducto}}/editar" class="btn btn-sm btn-outline-warning">Editar</a>

                                        <a href="/productos/{{$producto->idProducto}}/eliminar" class="btn btn-sm btn-outline-danger">Eliminar</a>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>

                <p><a class="btn btn-secondary" href=""></a></p>



            </div><!-- /.container -->



@endsection
